from importlib.metadata import version


def get_version():
    return version("limburg-flood-impact")
